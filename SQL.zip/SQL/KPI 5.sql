-- KPI 5 - Home Ownership vs. Last Payment Date Status 

SELECT f1.home_ownership, count(f2.last_pymnt_d)
AS COUNT_Of_Last_Payment_d FROM fn1 f1
INNER JOIN fn2 f2
ON f2.id = f1.id
GROUP BY 1;