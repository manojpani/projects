SELECT * FROM bankloan.fn1;
SELECT f1.addr_state as State,f1.loan_status,COUNT(f2.last_pymnt_d) AS Total_Count from fn1 f1
INNER JOIN fn2 f2
ON f2.id=f1.id
GROUP BY 1,2
ORDER BY 1,2;