SELECT * FROM bankloan.fn1;
-- KPI 3 - Total Payment for Verified Status vs. Total Payment for Non-Verfied Status
SELECT f1.verification_status, ROUND(SUM(f2.total_pymnt)) AS Total_Payment
FROM fn1 f1
INNER JOIN fn2 f2
ON f2.id = f1.id
GROUP BY 1
HAVING f1.verification_status IN ("Verified","Not Verified"); 