SELECT * FROM bankloan.fn1;
SELECT RIGHT(issue_d, 4) as Year, sum(loan_amnt) as Total_Loan_Amount
FROM fn1
GROUP BY 1
ORDER BY 1; 