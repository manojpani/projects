SELECT * FROM bankloan.fn1;
-- KPI 2 - Grade and Sub-Grade wise revol_bal
SELECT f1.grade, f1.sub_grade, sum(f2.revol_bal) as Total_Revol_Balance FROM fn1 as f1
INNER JOIN fn2 as f2
ON f2.id = f1.id
GROUP BY 1,2
ORDER BY 1,2;